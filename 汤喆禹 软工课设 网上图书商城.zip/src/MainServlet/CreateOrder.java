package MainServlet;

import Dao.DaoImpl.OrderDaoImpl;
import Dao.OrderDao;
import Pojo.Cart;
import Pojo.CartItem;
import Pojo.Order;
import Pojo.OrderItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

@WebServlet(name = "CreateOrder", urlPatterns = "/createorder")
public class CreateOrder extends HttpServlet {
    OrderDao od = new OrderDaoImpl();
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");

        String oper = req.getParameter("oper");
        if(oper.equals("FindOrder")){
            FindOrder(req,resp);
        }else if(oper.equals("AddOrder")){
            AddOrder(req,resp);
        }
        else if(oper.equals("GetAllOrder")){
            GetAllOrder(req,resp);
        }else if(oper.equals("Sendout")){
            Sendout(req,resp);
        }

    }
    private void Sendout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int Orderid = Integer.parseInt(req.getParameter("orderid"));
        od.UpdateState(Orderid);

    }
    private void GetAllOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Order> lo = od.GetAllOrder();

        req.setAttribute("AllOrder",lo);
        req.getRequestDispatcher("/BackMain/GetAllOrders.jsp").forward(req,resp);


    }

    private void FindOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession hs = req.getSession();
        try {
            int user_id = Integer.parseInt(req.getParameter("user_id"));

            List<Order> lo = od.FindUserOrder(user_id);
            hs.setAttribute("orders", lo);
        } catch (Exception e) {
            System.out.println(e);
        }
        resp.sendRedirect("/FontMain/MyOrder.jsp");
    }
    private void AddOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession hs = req.getSession();
        //拿到用户id
        int user_id = Integer.parseInt(req.getParameter("user_id"));
        //从session中拿到购物车的数据
        Cart ct = (Cart)hs.getAttribute("cart");
        //拿到购物车中具体map数据
        Map<Integer, CartItem> cartitems = ct.getMc();
       //设置Set order
        Set<OrderItem> so = new HashSet<>();
//        Order order = new Order(0,new Date(),ct.getPrice(),false,user_id);
        Order order = new Order();
        order.setId(0);
        for(int i:cartitems.keySet()){
            CartItem ci = cartitems.get(i);
            OrderItem ot = new OrderItem(0,ci.getBook().getId(),order.getId(),ci.getNumber(),ci.getPrice());
            so.add(ot);
        }
        order.setSo(so);
        order.setDate(new Date());
        order.setPrice(ct.getPrice());
        order.setState(false);
        order.setUser_id(user_id);

        //将order放入od
        od.AddOrder(order);
        List<Order> lo = od.FindUserOrder(user_id);
        hs.setAttribute("orders", lo);
        resp.sendRedirect("/FontMain/MyOrder.jsp");
    }
}
