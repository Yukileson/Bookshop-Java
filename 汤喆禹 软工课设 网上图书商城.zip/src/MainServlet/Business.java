package MainServlet;

import Pojo.Book;
import Pojo.Cart;
import Pojo.User;
import Service.BookService;
import Service.CategoryImpl.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "Business",urlPatterns = "/business")
public class Business extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");

        //检查用户是否登录
        HttpSession hs = req.getSession();
        User user  = (User)hs.getAttribute("user");
        if(user ==null){
            req.setAttribute("message","请先登录后购买");
            req.getRequestDispatcher("/FontMain/Mycart.jsp").forward(req,resp);
        }

        String oper = req.getParameter("oper");
        if(oper.equals("deleteItem")){
            DeleteItem(req,resp);
        }else if(oper.equals("addItem")){
            AddItem(req,resp);
        }



    }
    private void AddItem(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession hs = req.getSession();
        Cart ct = (Cart)hs.getAttribute("cart");
        if( ct== null){
            ct = new Cart();
        }

        int bookid =  Integer.parseInt(req.getParameter("bookid"));
        BookService bs = new BookServiceImpl();
        Book book = bs.FindBook(bookid);
        ct.AddBook(book);

        hs.setAttribute("cart",ct);
    }
    private void DeleteItem(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession hs = req.getSession();
        Cart ct = (Cart)hs.getAttribute("cart");

        int itemid = Integer.parseInt(req.getParameter("itemid"));

        ct.DeleteItem(itemid);
        hs.setAttribute("cart",ct);
        resp.getWriter().write("总价："+String.valueOf(ct.getPrice()));
    }

}
