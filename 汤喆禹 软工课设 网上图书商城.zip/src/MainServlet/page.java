package MainServlet;

import Pojo.Book;
import Pojo.Category;
import Service.BookService;
import Service.CategoryImpl.BookServiceImpl;
import Service.CategoryImpl.CategoryServiceImpl;
import Service.CategoryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "page",urlPatterns = "/page")
public class page extends HttpServlet {
    CategoryService cs = new CategoryServiceImpl();
    BookService bs = new BookServiceImpl();
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        resp.getWriter().write("page页面");
        String oper = req.getParameter("oper");
        if(oper.equals("addList")){
            AddList(req,resp);
        }else if(oper.equals("showCategory")){
            ShowCategory(req,resp);
        }else if(oper.equals("deleteCategory")){
            DeleteCategory(req,resp);
        }else if(oper.equals("addCategoryUi")){
            AddCategoryUi(req,resp);
        }else if(oper.equals("addbook")){
            AddBook(req,resp);
        }else if(oper.equals("showBooks")){
            ShowBooks(req,resp);
        }else if(oper.equals("deleteBook")){
            DeleteBook(req,resp);
        }

    }
    private void AddList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String categoryName = req.getParameter("categoryName");
        String categoryDescrption = req.getParameter("CategoryDescription");
        Category category = new Category();
        category.setName(categoryName);
        category.setDescription(categoryDescrption);
        System.out.println(category);
        int result = cs.AddCategory(category);
        if(result>0){
            req.setAttribute("flag",1);
            req.getRequestDispatcher("/BackMain/AddCategory.jsp").forward(req,resp);
        }
    }
    private void ShowCategory(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Category> lc = cs.ShowAllCategory();
        HttpSession hs = req.getSession();
        hs.setAttribute("Catelist",lc);
//        req.setAttribute("Catelist",lc);
        resp.sendRedirect("/BackMain/ShowCategory.jsp");
    }
    private void DeleteCategory(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int CategoryId = Integer.parseInt(req.getParameter("CategoryId"));
        int result = cs.DeleteCategory(CategoryId);
    }
    private void AddCategoryUi(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Category> lc = cs.ShowAllCategory();
        req.setAttribute("category",lc);
        req.getRequestDispatcher("/BackMain/AddBook.jsp").forward(req,resp);
    }
    private void AddBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String author = req.getParameter("author");
        float price = Float.parseFloat(req.getParameter("price"));
        int categoryId = Integer.parseInt(req.getParameter("categoryId"));
        String imageId = req.getParameter("imageId");
        String descirption = req.getParameter("description");
        System.out.println(name+author+price+categoryId+imageId+descirption);
        Book book = new Book(0,categoryId,name,descirption,author,price,imageId);
        int result = bs.AddBook(book);
        if(result>0){
            req.setAttribute("message",1);
            req.getRequestDispatcher("/BackMain/AddBook.jsp").forward(req,resp);
        }
    }
    private void ShowBooks(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Book> lb = bs.ShowAllBooks();
        req.setAttribute("BookList",lb);
        req.getRequestDispatcher("/BackMain/ShowBook.jsp").forward(req,resp);

    }
    private void DeleteBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int bookId = Integer.parseInt(req.getParameter("BookId"));
        int result = bs.DeleteBook(bookId);
    }
}
