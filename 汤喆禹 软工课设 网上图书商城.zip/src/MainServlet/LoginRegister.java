package MainServlet;

import Pojo.User;
import Service.CategoryImpl.UserServiceImpl;
import Service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "LoginRegister",urlPatterns = "/registerlogin")
public class LoginRegister extends HttpServlet {
    UserService us = new UserServiceImpl();
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String oper = req.getParameter("oper");
        if(oper.equals("register")){
            Register(req,resp);
        }else if(oper.equals("login")){
            Login(req,resp);
        }else if(oper.equals("exit")){
            ToExit(req,resp);
        }
    }
    private void Register(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uname = req.getParameter("uname");
        String pwd = req.getParameter("pwd");
        String email = req.getParameter("email");
        User u = new User(0,uname,pwd,email);
        int result = us.AddUser(u);
        if(result>0){
            req.setAttribute("message",0);
            req.getRequestDispatcher("/FontMain/Index.jsp").forward(req,resp);
        }

    }
    private void Login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String luname = req.getParameter("luname");
        String lpwd = req.getParameter("lpwd");
        if(luname.equals("admin")&&lpwd.equals("admin")){
            req.getRequestDispatcher("/BackMain/AddCategory.jsp").forward(req,resp);
        }
        User u = new User();
        u.setUname(luname);
        u.setPwd(lpwd);

        User nu = us.CheckUser(u);
        if(nu !=null){
            HttpSession hs=req.getSession();
            hs.setAttribute("user",nu);
            resp.sendRedirect("/FontMain/Index.jsp");
        }else{
            req.setAttribute("message2",0);
            req.getRequestDispatcher("/FontMain/Index.jsp").forward(req,resp);
        }
    }
    private void ToExit(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession hs =req.getSession();
        hs.invalidate();
        resp.sendRedirect("/FontMain/Index.jsp");
    }
}
