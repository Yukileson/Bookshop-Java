package MainServlet;

import Pojo.Book;
import Service.BookService;
import Service.CategoryImpl.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "bookshow",urlPatterns = "/bookshow")
public class bookshow extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        BookService bs = new BookServiceImpl();
        String categoryid =  req.getParameter("categoryid");
        if(categoryid ==null) {
            List<Book> lb = bs.ShowAllBooks();
            req.setAttribute("books", lb);
            req.getRequestDispatcher("FontMain/bookright.jsp").include(req, resp);
        }else{
            int id = Integer.parseInt(categoryid);
            List<Book> lb =bs.ShowCategoryBooks(id);
            req.setAttribute("books", lb);
            req.getRequestDispatcher("FontMain/bookright.jsp").include(req, resp);
        }

    }
}
