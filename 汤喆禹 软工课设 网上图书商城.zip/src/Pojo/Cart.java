package Pojo;

import java.util.HashMap;
import java.util.Map;

public class Cart {
    private Map<Integer,CartItem> mc = new HashMap<>();
    //书籍id 和 购物项
    private float allprice;

    public void AddBook(Book book){
        CartItem cartItem = mc.get(book.id);
        if(cartItem ==null){
            cartItem = new CartItem();
            cartItem.setBook(book);
            cartItem.setNumber(1);
            mc.put(book.id,cartItem);
        }else{
            int currentnum =  cartItem.getNumber();
            cartItem.setNumber(++currentnum);
        }
    }

    public void DeleteItem(int bookid){
     mc.remove(bookid);
    }

    public Map<Integer, CartItem> getMc() {
        return mc;
    }

    public void setMc(Map<Integer, CartItem> mc) {
        this.mc = mc;
    }

    public float getPrice(){
          allprice = 0;
        for(int i:mc.keySet()){
           CartItem ci = mc.get(i);
           allprice += ci.getPrice();
        }
        return allprice;
    }


}
