package Pojo;

import java.util.Objects;

public class Book {
    int id;
    int category_id;
    String name;
    String description;
    String author;
    float price;
    String image_id;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id == book.id &&
                category_id == book.category_id &&
                Float.compare(book.price, price) == 0 &&
                Objects.equals(name, book.name) &&
                Objects.equals(description, book.description) &&
                Objects.equals(author, book.author) &&
                Objects.equals(image_id, book.image_id);
    }

    public Book() {

    }

    public Book(int id, int category_id, String name, String description, String author, float price, String image_id) {
        this.id = id;
        this.category_id = category_id;
        this.name = name;
        this.description = description;
        this.author = author;
        this.price = price;
        this.image_id = image_id;
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, category_id, name, description, author, price, image_id);
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", category_id=" + category_id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                ", image_id='" + image_id + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getImage_id() {
        return image_id;
    }

    public void setImage_id(String image_id) {
        this.image_id = image_id;
    }
}
