package Pojo;

public class OrderItem {
    private  int id;
    private int book_id;
    private  int order_id;

    public int getOrder_id() {
        return order_id;
    }

    public OrderItem(int id, int book_id, int order_id, int number, float price) {
        this.id = id;
        this.book_id = book_id;
        this.order_id = order_id;
        this.number = number;
        this.price = price;
    }

    @Override
    public String toString() {
        return "OrderItem{" +
                "id=" + id +
                ", book_id=" + book_id +
                ", order_id=" + order_id +
                ", number=" + number +
                ", price=" + price +
                '}';
    }

    public OrderItem() {

    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;

    }

    private int number;
    private float price;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
