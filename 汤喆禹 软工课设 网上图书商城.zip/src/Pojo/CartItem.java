package Pojo;

public class CartItem {
    private Book book;
    private int number;
    private float price;

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public float getPrice() {
        return number*book.getPrice();
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "CartItem{" +
                "book=" + book +
                ", number=" + number +
                ", price=" + price +
                '}';
    }

    public CartItem() {
    }

    public CartItem(Book book, int number, float price) {
        this.book = book;
        this.number = number;
        this.price = price;
    }
}
