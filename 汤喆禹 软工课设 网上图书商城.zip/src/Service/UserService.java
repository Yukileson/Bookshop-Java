package Service;

import Pojo.User;

public interface UserService {
    int AddUser(User user);
    User CheckUser(User user);
    User FindUser(int id);
}
