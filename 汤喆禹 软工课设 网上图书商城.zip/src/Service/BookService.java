package Service;

import Pojo.Book;

import java.util.List;

public interface BookService {
    int AddBook(Book book);
    int DeleteBook(int id);
    List<Book> ShowAllBooks();
    Book FindBook(int id);
    List<Book> ShowCategoryBooks(int id);
}
