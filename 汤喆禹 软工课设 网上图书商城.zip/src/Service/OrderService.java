package Service;

import Pojo.Order;

import java.util.List;

public interface OrderService {
    int AddOrder(Order order);
    List<Order> FindUserOrder(int user_id);
    List<Order> GetAllOrder();
    int UpdateState(int id);
    Order FindOrder(int id);
}
