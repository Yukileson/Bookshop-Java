package Service.CategoryImpl;

import Dao.CategoryDao;
import Dao.DaoImpl.CategoryDaoImpl;
import Pojo.Category;
import Service.CategoryService;

import java.util.List;

public class CategoryServiceImpl implements CategoryService {
    CategoryDao cd = new CategoryDaoImpl();
    @Override
    public int AddCategory(Category category) {

        int result = cd.AddCategory(category);
        if(result>0){
            System.out.println("添加成功");
        }else {
            System.out.println("添加失败");
        }
        return result;
    }

    @Override
    public Category FindCategory(int id) {
        return cd.FindCategory(id);
    }

    @Override
    public List<Category> ShowAllCategory() {
        return cd.ShowAllCategory();
    }

    @Override
    public int DeleteCategory(int id) {
        int result = cd.DeleteCategory(id);
        if(result>0){
            System.out.println("删除成功");
        }else {
            System.out.println("删除失败");
        }
        return result;
    }
}
