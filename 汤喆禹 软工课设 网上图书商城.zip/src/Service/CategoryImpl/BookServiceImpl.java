package Service.CategoryImpl;

import Dao.BookDao;
import Dao.DaoImpl.BookDaoImpl;
import Pojo.Book;
import Pojo.Category;
import Service.BookService;

import java.util.List;

public class BookServiceImpl implements BookService {
    BookDao bd = new BookDaoImpl();
    @Override
    public int AddBook(Book book) {
        int result =bd.AddBook(book);
        if(result>0){
            System.out.println("添加图书成功");
        }else{
            System.out.println("添加图书失败");
        }
        return result;
    }

    @Override
    public int DeleteBook(int id) {
        int result =bd.DeleteBook(id);
        if(result>0){
            System.out.println("删除图书成功");
        }else{
            System.out.println("删除图书失败");
        }
        return result;
    }

    @Override
    public List<Book> ShowAllBooks() {
        return bd.ShowAllBooks();
    }

    @Override
    public Book FindBook(int id) {
        return bd.FindBook(id);
    }

    @Override
    public List<Book> ShowCategoryBooks(int id) {
        return bd.ShowCategoryBook(id);
    }
}
