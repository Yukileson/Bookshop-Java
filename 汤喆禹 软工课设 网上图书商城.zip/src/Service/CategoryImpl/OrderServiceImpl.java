package Service.CategoryImpl;

import Dao.DaoImpl.OrderDaoImpl;
import Dao.OrderDao;
import Pojo.Order;
import Service.OrderService;

import java.util.List;

public class OrderServiceImpl implements OrderService {
    OrderDao od = new OrderDaoImpl();

    @Override
    public Order FindOrder(int id) {

        return od.FindOrder(id);
    }

    @Override
    public List<Order> GetAllOrder() {
        return od.GetAllOrder();
    }

    @Override
    public int AddOrder(Order order) {
        int result = od.AddOrder(order);
        if(result >0 ){
            System.out.println("新键订单成功");
        }else{
            System.out.println("新键订单失败");
        }
        return result;
    }

    @Override
    public List<Order> FindUserOrder(int user_id) {
        return od.FindUserOrder(user_id);
    }

    @Override
    public int UpdateState(int id) {
        int result = od.UpdateState(id);
        if(result > 0 ){
            System.out.println("发货陈宫");
        }else{
            System.out.println("发货失败");
        }
        return result;
    }
}
