package Service.CategoryImpl;

import Dao.DaoImpl.UserDaoImpl;
import Dao.UserDao;
import Pojo.User;
import Service.UserService;

public class UserServiceImpl implements UserService {
    UserDao ud = new UserDaoImpl();
    @Override
    public int AddUser(User user) {
        int result = ud.AddUser(user);
        if(result >0){
            System.out.println("注册成功");
        }else {
            System.out.println("注册失败");
        }
        return result;
    }

    @Override
    public User CheckUser(User user) {
        User u = ud.CheckUser(user);
        if(u == null){
            System.out.println("登录失败");
        }else{
            System.out.println("登录成功");
        }
        return u;
}

    @Override
    public User FindUser(int id) {
        return ud.FindUser(id);
    }
}
