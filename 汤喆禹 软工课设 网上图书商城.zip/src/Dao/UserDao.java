package Dao;

import Pojo.User;

public interface UserDao {
    int AddUser(User user);
    User CheckUser(User user);
    User FindUser(int id);
}
