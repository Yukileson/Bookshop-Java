package Dao;

import Pojo.Order;

import java.util.List;

public interface OrderDao {
    int AddOrder(Order order);
    List<Order> FindUserOrder(int user_id);
    List<Order> GetAllOrder();
    int UpdateState(int id);
    Order FindOrder(int id);
}
