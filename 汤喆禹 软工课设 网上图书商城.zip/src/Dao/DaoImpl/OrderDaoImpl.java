package Dao.DaoImpl;

import Dao.OrderDao;
import Pojo.Order;
import Pojo.OrderItem;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OrderDaoImpl implements OrderDao {
    private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
    private static QueryRunner queryRunner = new QueryRunner(dataSource);
    @Override
    public int AddOrder(Order order) {
        int result = 0;
        try {
            String sql = "insert into orders(id,date,user_id,state,price) values(?,?,?,?,?)";
            result = queryRunner.update(sql, new Object[]{order.getId(),order.getDate(),order.getUser_id(),order.isState(),order.getPrice()});
            String sql3 = "select id from orders order by id DESC limit 1";
            Order norder = (Order) queryRunner.query(sql3, new BeanHandler(Order.class));
            String sql2 = "insert into orderItem(id,price,number,order_id,book_id) values(?,?,?,?,?)";
            Set<OrderItem> so = order.getSo();
            for(OrderItem item:so){
                queryRunner.update(sql2,new Object[]{item.getId(),item.getPrice(),item.getNumber(),norder.getId(),item.getBook_id()});
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return result;
    }

    @Override
    public int UpdateState(int id) {
        int result = 0;
        try{
            String sql = "update orders set state=? where id=? ";
            result = queryRunner.update(sql, new Object[]{true, id});
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    @Override
    public List<Order> FindUserOrder(int user_id) {
        List<Order> lo = new ArrayList<>();
        try{
            String sql = "select * from  orders where user_id = ?";
            lo = ( List<Order>) queryRunner.query(sql,user_id,new BeanListHandler(Order.class));
            String sql2 = "select * from orderitem where order_id = ?";
            for(Order order:lo){
                List<OrderItem> items = (List<OrderItem>)queryRunner.query(sql2,order.getId(),new BeanListHandler(OrderItem.class));
                Set<OrderItem> Tosetitems=new HashSet<>(items);
                order.setSo(Tosetitems);
            }

        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return lo;
    }

    @Override
    public List<Order> GetAllOrder() {
        List<Order> lo = null;
        try{
            String sql = "select * from  orders";
            lo = ( List<Order>) queryRunner.query(sql, new BeanListHandler(Order.class));
            String sql2 = "select * from orderitem where order_id = ?";
            for(Order order:lo){
                List<OrderItem> items = (List<OrderItem>)queryRunner.query(sql2,order.getId(),new BeanListHandler(OrderItem.class));
                Set<OrderItem> Tosetitems=new HashSet<>(items);
                order.setSo(Tosetitems);
            }

        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return lo;
    }

    @Override
    public Order FindOrder(int id) {
        Order order;
        try {
            String sql = "select * from  orders where id = ?";
            order = (Order) queryRunner.query(sql, id, new BeanHandler(Order.class));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return order;
    }
}
