package Dao.DaoImpl;

import Dao.CategoryDao;
import Pojo.Category;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDaoImpl implements CategoryDao {
    private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
    private static QueryRunner queryRunner = new QueryRunner(dataSource);
    @Override
    public int AddCategory(Category category) {
        int result = 0;
        String sql = "INSERT INTO category (id, name, description) VALUES(?,?,?)";
            try {
         result = queryRunner.update(sql, new Object[]{category.getId(), category.getName(), category.getDescription()});
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return result;
    }

    @Override
    public Category FindCategory(int id) {
        Category category;
        String sql = "Select * from category where id = ?";
        try{
           category = (Category) queryRunner.query(sql, id, new BeanHandler(Category.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return category;
    }

    @Override
    public List<Category> ShowAllCategory() {
        List<Category> cl = new ArrayList<>();
        String sql = "Select * from category";
        try{
            cl = ( List<Category>) queryRunner.query(sql, new BeanListHandler(Category.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return cl;

    }

    @Override
    public int DeleteCategory(int id) {
        int result = 0;
        String sql = "delete from category where id = ?";
        try {
            result = queryRunner.update(sql, id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }
}
