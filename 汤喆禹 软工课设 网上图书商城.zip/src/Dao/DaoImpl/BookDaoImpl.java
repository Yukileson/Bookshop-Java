package Dao.DaoImpl;

import Dao.BookDao;
import Pojo.Book;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDaoImpl implements BookDao {
    private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
    private static QueryRunner queryRunner = new QueryRunner(dataSource);
    @Override
    public int AddBook(Book book) {
        int result = 0;
        String sql = "insert into book(id,category_id,name,description,author,price,image_id) values(?,?,?,?,?,?,?)";
        try {
            result = queryRunner.update(sql, new Object[]{book.getId(),book.getCategory_id(),book.getName(),book.getDescription(),book.getAuthor(),book.getPrice(),book.getImage_id()});
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    @Override
    public int DeleteBook(int id) {
        int result = 0;
        String sql = "delete from book where id = ?";
        try{
            result = queryRunner.update(sql, id);
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    @Override
    public List<Book> ShowAllBooks() {
        List<Book> lb = new ArrayList<>();
        String sql = "Select * from book";
        try{
            lb = ( List<Book>) queryRunner.query(sql, new BeanListHandler(Book.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return lb;
    }

    @Override
    public Book FindBook(int id) {
        Book book;
        String sql = "Select * from book where id = ?";
        try{
            book = (Book) queryRunner.query(sql, id, new BeanHandler(Book.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return book;
    }

    @Override
    public List<Book> ShowCategoryBook(int id) {
        List<Book> lb = new ArrayList<>();
        String sql = "Select * from book where category_id = ?";
        try{
            lb = ( List<Book>) queryRunner.query(sql,id,new BeanListHandler(Book.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return lb;
    }
}
