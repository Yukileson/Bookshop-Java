package Dao.DaoImpl;

import Dao.UserDao;
import Pojo.Category;
import Pojo.User;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

public class UserDaoImpl implements UserDao {
    private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
    private static QueryRunner queryRunner = new QueryRunner(dataSource);
    @Override
    public int AddUser(User user) {
        int result = 0;
        String sql = "insert into user(id,uname,pwd,email) values(?,?,?,?);";
        try {
            result = queryRunner.update(sql, new Object[]{user.getId(), user.getUname(), user.getPwd(),user.getEmail()});
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    @Override
    public User CheckUser(User user) {
        User u = new User();
        System.out.println(user);
        String sql = "select * from user where uname = ? and pwd = ?";
        try{
            u = (User) queryRunner.query(sql, new Object[]{user.getUname(),user.getPwd()}, new BeanHandler(User.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        System.out.println(u);
        return u;

    }

    @Override
    public User FindUser(int id) {
        User u = new User();
        String sql ="select * from user where id = ?";
        try{
            u = (User) queryRunner.query(sql,id, new BeanHandler(User.class));
        }catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return u;
    }
}
