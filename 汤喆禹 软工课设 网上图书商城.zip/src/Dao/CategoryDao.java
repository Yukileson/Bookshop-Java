package Dao;

import Pojo.Category;

import java.util.List;

public interface CategoryDao {
    int AddCategory(Category category);
    Category FindCategory(int id);
    List<Category> ShowAllCategory();
    int DeleteCategory(int id);
}
