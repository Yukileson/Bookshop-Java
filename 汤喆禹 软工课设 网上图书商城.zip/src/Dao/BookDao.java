package Dao;

import Pojo.Book;

import java.util.List;

public interface BookDao {
    int AddBook(Book book);
    int DeleteBook(int id);
    List<Book> ShowAllBooks();
    Book FindBook(int id);
    List<Book> ShowCategoryBook(int id);
}
