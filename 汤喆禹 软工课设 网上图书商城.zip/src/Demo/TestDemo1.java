package Demo;

import Dao.BookDao;
import Dao.CategoryDao;
import Dao.DaoImpl.BookDaoImpl;
import Dao.DaoImpl.CategoryDaoImpl;
import Dao.DaoImpl.OrderDaoImpl;
import Dao.DaoImpl.UserDaoImpl;
import Dao.OrderDao;
import Dao.UserDao;
import Pojo.*;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TestDemo1 {
    public static void main(String[] args) {
//        Category category = new Category();
//        category.setName("为什么会乱码");
//        category.setDescription("这什么鬼东西啊");
//        CategoryDao cd = new CategoryDaoImpl();
//        cd.AddCategory(category);
//        System.out.println(cd.FindCategory(71));
//        cd.ShowAllCategory();

//        Book book = new Book();
//        book.setId(0);
//        book.setCategory_id(71);
//        book.setAuthor("aaaaa");
//        book.setDescription("aaa");
//        book.setName("aaaa");
//        book.setPrice(123);
//        BookDao bd = new BookDaoImpl();
//        bd.AddBook(book);

//        System.out.println( bd.FindBook(8));
//        bd.DeleteBook(7);
//        List<Book> lb = bd.ShowAllBooks();
//        for (Book b : lb) {
//            System.out.println(b);
//        }

//        List<Book> lb2 =   bd.ShowCategoryBook(71);
//        for (Book b : lb2) {
//            System.out.println(b);
////        }
//        User u = new User(8,"dai","789","109@11");
//        User u2 = new User(7,"m","m","");
//        UserDao us = new UserDaoImpl();
////        us.AddUser(u);
//        User u3 = us.CheckUser(u);
//        User u4  = us.FindUser(3);
//        System.out.println(u3);
//        System.out.println(u4);

        OrderItem ot1 = new OrderItem(0,21,2,2,12);
        OrderItem ot2 = new OrderItem(0,22,2,3,12);
        OrderItem ot3 = new OrderItem(0,22,2,3,12);
        Set<OrderItem> items = new HashSet<>();
        items.add(ot1);
        items.add(ot2);
        items.add(ot3);
//        Order od = new Order(1,new Date(),23,false,1,items);
//

//        Order od2 = new Order(2,new Date(),23,false,1,items);
        OrderDao odao = new OrderDaoImpl();
//        odao.AddOrder(od2);
////        odao.AddOrder(od);
//
//        System.out.println(odao.FindOrder(1));
//        System.out.println(odao.FindOrder(1));
       List<Order> lo = odao.GetAllOrder();
        System.out.println(lo);
        for(Order order:lo){
            for(OrderItem item:order.getSo()){
                System.out.println(item);
            }
        }
        odao.UpdateState(2);
        System.out.println(odao.FindOrder(2));

    }
}

