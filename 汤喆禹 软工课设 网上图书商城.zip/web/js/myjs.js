if(document.getElementsByClassName("result")[0]){
    alert("注册成功")
}
if(document.getElementsByClassName("result2")[0]){
    alert("账号或密码错误")
}
document.getElementsByClassName("exit")[0].onclick = function () {
    var mini_login = document.getElementsByClassName("login")[0];
    var cover = document.getElementsByClassName("cover")[0];
    mini_login.style.display = "none";
    cover.style.display = "none";
}
document.getElementsByClassName("exit")[1].onclick = function () {
    var mini_register = document.getElementsByClassName("register")[0];
    var cover = document.getElementsByClassName("cover")[0];
    mini_register.style.display = "none";
    cover.style.display = "none";
}
document.getElementById("registerpanel").onsubmit = function () {
    if(document.getElementById("zhanghao").value ==""){
        alert("账号不能为空");
        return false;
    }else if(document.getElementById("pwd").value ==""){
        alert("新密码不能为空");
        return false;
    }else if(document.getElementById("checkpwd").value == ""){
        alert("确认密码不能为空");
        return false
    }else  if(document.getElementById("pwd").value != document.getElementById("checkpwd").value){
        alert("新密码与确认密码不一致");
        return false;
    }else {
        return true;
    }
}


if(document.getElementById("myname")){
    document.getElementById("loginbutton").style.display = "none";
    document.getElementById("registerbutton").style.display = "none";

}
function Toactive() {
    this.classList.add("active");
}
document.getElementById("loginbutton").onclick = function () {
    var mini_login = document.getElementsByClassName("login")[0];
    var cover = document.getElementsByClassName("cover")[0];
    mini_login.style.display = "block";
    cover.style.display = "block";
    console.log("aaa");
}
document.getElementById("registerbutton").onclick = function () {
    var mini_register = document.getElementsByClassName("register")[0];
    var cover = document.getElementsByClassName("cover")[0];
    mini_register.style.display = "block";
    cover.style.display = "block";
}
