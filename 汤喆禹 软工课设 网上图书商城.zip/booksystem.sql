/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50723
Source Host           : localhost:3306
Source Database       : booksystem

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2019-12-17 22:13:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `author` varchar(20) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `image_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id_fk` (`category_id`),
  CONSTRAINT `category_id_fk` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('21', '81', '禅语摩托车的维修', '好像快要看睡着了', '忘了', '23.42', '22504494-1_b_1.jpg');
INSERT INTO `book` VALUES ('22', '71', 'java编程思想', '这本书很好 但是太难了', '埃克尔', '78', '9317290-1_b_5.jpg');
INSERT INTO `book` VALUES ('25', '71', '百年孤独', '不好看', '西亚·马尔克斯', '31', '25138856-1_b_2.jpg');
INSERT INTO `book` VALUES ('26', '83', '滑稽学', '太滑稽了', '我啊', '23.9', 'a6865c85ly1g8oog0cw75j20c80c83ze.jpg');
INSERT INTO `book` VALUES ('27', '84', '快速养猪致富', '发财啦', '不知道', '872', 'a6865c85ly1g8oog0eut5j20c80c8dgv.jpg');
INSERT INTO `book` VALUES ('28', '92', '如何让富婆爱上你', '发家致富新道路', '忘了', '562', 'a6865c85ly1g8oog0f5kuj20c80lvmy5.jpg');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('71', '计算机书籍', '太好看了吧');
INSERT INTO `category` VALUES ('81', '文学书籍', '这个有点无聊诶\r\n');
INSERT INTO `category` VALUES ('83', '恐怖书籍', '看的把人吓死了');
INSERT INTO `category` VALUES ('84', 'R18成人书籍', '小孩子不能看的哟');
INSERT INTO `category` VALUES ('90', 'bl书籍', '搞基');
INSERT INTO `category` VALUES ('91', '鸡汤书籍', '看了让人开心');
INSERT INTO `category` VALUES ('92', '网络文学', '太好看了 ，打磨时间的神器');
INSERT INTO `category` VALUES ('98', '心理书籍', '我都快抑郁症了');
INSERT INTO `category` VALUES ('112', '为什么会乱码', '这什么鬼东西啊');
INSERT INTO `category` VALUES ('113', '为什么会乱码', '这什么鬼东西啊');
INSERT INTO `category` VALUES ('115', '散文', '这个看起来很无聊');

-- ----------------------------
-- Table structure for orderitem
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id_fk` (`order_id`),
  KEY `book_id_fk` (`book_id`),
  CONSTRAINT `book_id_fk` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`),
  CONSTRAINT `order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO `orderitem` VALUES ('1', '12', '2', '1', '21');
INSERT INTO `orderitem` VALUES ('2', '12', '3', '1', '22');
INSERT INTO `orderitem` VALUES ('3', '12', '3', '2', '22');
INSERT INTO `orderitem` VALUES ('4', '12', '3', '2', '22');
INSERT INTO `orderitem` VALUES ('5', '12', '2', '2', '21');
INSERT INTO `orderitem` VALUES ('7', '23.42', '1', '6', '21');
INSERT INTO `orderitem` VALUES ('8', '78', '1', '6', '22');
INSERT INTO `orderitem` VALUES ('9', '46.84', '2', '7', '21');
INSERT INTO `orderitem` VALUES ('10', '23.9', '1', '8', '26');
INSERT INTO `orderitem` VALUES ('11', '31', '1', '8', '25');
INSERT INTO `orderitem` VALUES ('12', '156', '2', '8', '22');
INSERT INTO `orderitem` VALUES ('13', '47.8', '2', '9', '26');
INSERT INTO `orderitem` VALUES ('14', '78', '1', '10', '22');
INSERT INTO `orderitem` VALUES ('15', '46.84', '2', '10', '21');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_fk` (`user_id`),
  CONSTRAINT `user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1', '2019-11-20', '1', '1', '23');
INSERT INTO `orders` VALUES ('2', '2019-11-20', '1', '1', '23');
INSERT INTO `orders` VALUES ('3', '2019-11-22', '1', '0', '46.84');
INSERT INTO `orders` VALUES ('4', '2019-11-22', '1', '1', '101.42');
INSERT INTO `orders` VALUES ('5', '2019-11-22', '1', '1', '54.42');
INSERT INTO `orders` VALUES ('6', '2019-11-22', '1', '0', '101.42');
INSERT INTO `orders` VALUES ('7', '2019-11-22', '2', '0', '46.84');
INSERT INTO `orders` VALUES ('8', '2019-11-22', '2', '0', '210.9');
INSERT INTO `orders` VALUES ('9', '2019-11-22', '1', '1', '47.8');
INSERT INTO `orders` VALUES ('10', '2019-12-10', '1', '0', '124.84');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'tang', '123', null);
INSERT INTO `user` VALUES ('2', 'wang', '456', '1019751314@qq.com');
INSERT INTO `user` VALUES ('3', 'wang', '456', '1019751314@qq.com');
INSERT INTO `user` VALUES ('4', 'd', '4456', '');
INSERT INTO `user` VALUES ('8', 'dai', '789', '109@11');
INSERT INTO `user` VALUES ('9', '1231', '19992', '1019751314@qq.com');
INSERT INTO `user` VALUES ('10', '1231', '19992', '1019751314@qq.com');
INSERT INTO `user` VALUES ('11', '1231', '19992', '1019751314@qq.com');
INSERT INTO `user` VALUES ('12', '123', '234', '1019751314@qq.com');
INSERT INTO `user` VALUES ('13', '123', '234', '1019751314@qq.com');
INSERT INTO `user` VALUES ('14', 'tang', '123', '1019751314@qq.com');
INSERT INTO `user` VALUES ('15', 'tang', '12', '1019751314@qq.com');
INSERT INTO `user` VALUES ('16', 'tang', '12', '1019751314@qq.com');
INSERT INTO `user` VALUES ('17', 'tang', '12', '1019751314@qq.com');
INSERT INTO `user` VALUES ('18', 'tang', '12', '1019751314@qq.com');
INSERT INTO `user` VALUES ('19', 'tang', '123', '1019751314@qq.com');
INSERT INTO `user` VALUES ('20', 'tang', '123', '1019751314@qq.com');
